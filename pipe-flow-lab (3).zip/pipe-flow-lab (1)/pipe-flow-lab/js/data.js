// ── Experimental Dataset ──────────────────────────────────────────────────────
const DATASET = [
  { id:1, D:0.027,  flow:1, time:39.13, hHg:13, Q:0.000613, V:1.071, hf:0.164, Re:28923.29, f:0.0504 },
  { id:2, D:0.027,  flow:2, time:33.04, hHg:25, Q:0.000726, V:1.269, hf:0.315, Re:34254.49, f:0.0691 },
  { id:3, D:0.027,  flow:3, time:32.47, hHg:28, Q:0.000739, V:1.291, hf:0.353, Re:34855.82, f:0.0748 },
  { id:4, D:0.0215, flow:1, time:40.16, hHg:26, Q:0.000598, V:1.646, hf:0.328, Re:35390.70, f:0.0340 },
  { id:5, D:0.0215, flow:2, time:33.82, hHg:45, Q:0.000710, V:1.955, hf:0.567, Re:42025.15, f:0.0417 },
  { id:6, D:0.0215, flow:3, time:32.60, hHg:51, Q:0.000736, V:2.028, hf:0.643, Re:43597.87, f:0.0439 },
];

// Physical constants
const CONSTANTS = {
  rho:    1000,    // kg/m³  water density
  mu:     0.001,   // Pa·s   dynamic viscosity
  g:      9.81,    // m/s²
  rhoHg:  13600,   // kg/m³  mercury density
  L:      1.5,     // m      pipe length between tappings
  tankA:  0.12,    // m²     collecting tank cross-section
  vol:    0.024,   // m³     volume collected (fixed 24 litres)
};

// ── Lookup helpers ────────────────────────────────────────────────────────────
function getRow(diameter, flowLevel) {
  return DATASET.find(r => r.D === diameter && r.flow === flowLevel) || null;
}

// ── Physics formulas (student-side recalculation) ─────────────────────────────
function calcQ(vol, time)       { return vol / time; }
function calcA(D)               { return Math.PI * D * D / 4; }
function calcV(Q, D)            { return Q / calcA(D); }
function calcHf(hHg)            { return hHg / 1000 * (CONSTANTS.rhoHg / CONSTANTS.rho - 1); }
function calcRe(V, D)           { return CONSTANTS.rho * V * D / CONSTANTS.mu; }
function calcF(hf, D, V)        { return (2 * CONSTANTS.g * hf * D) / (CONSTANTS.L * V * V); }

// Tolerance check  (±5%)
function withinTol(calc, ref, pct = 5) {
  if (!ref) return false;
  return Math.abs((calc - ref) / ref) * 100 <= pct;
}

// ── Quiz bank ─────────────────────────────────────────────────────────────────
const QUIZ_BANK = [
  { q:"What does the Darcy-Weisbach friction factor 'f' represent?",
    opts:["Flow velocity","Energy loss coefficient","Pipe roughness only","Reynolds number"],
    ans:1 },
  { q:"Major losses in pipe flow are caused by:",
    opts:["Bends and valves","Friction along pipe length","Entry effects","Fittings"],
    ans:1 },
  { q:"As Reynolds number increases (turbulent), friction factor generally:",
    opts:["Increases sharply","Stays constant","Decreases slightly","Becomes zero"],
    ans:2 },
  { q:"The U-tube manometer in this experiment uses mercury because:",
    opts:["It is cheap","Large density difference gives readable deflection","It is non-toxic","Water gives same reading"],
    ans:1 },
  { q:"Hydraulic head loss hf from mercury manometer reading hHg is:",
    opts:["hHg × (ρHg/ρ)","hHg × (ρHg/ρ − 1)","hHg / ρHg","ρ × g × hHg"],
    ans:1 },
  { q:"The Darcy-Weisbach equation is: hf =",
    opts:["f·L·V²/(D·2g)","f·D·V²/(L·2g)","4f·L·V/(D·2g)","f·L/(D·V²)"],
    ans:0 },
  { q:"For the 21.5 mm pipe at flow level 1, which is closest to Re?",
    opts:["25 000","36 864","50 000","12 000"],
    ans:1 },
  { q:"A higher friction factor 'f' with the same Re for a smaller pipe suggests:",
    opts:["Lower roughness","Higher roughness ratio ε/D","Laminar regime","Lower velocity"],
    ans:1 },
  { q:"Reynolds number is defined as:",
    opts:["ρVD/μ","μVD/ρ","ρV²D/μ","V²/gD"],
    ans:0 },
  { q:"The collecting tank method measures flow rate by recording:",
    opts:["Volume vs pressure","Time to collect a fixed volume","Velocity at outlet","Pipe pressure drop"],
    ans:1 },
];

// ── Viva questions ────────────────────────────────────────────────────────────
const VIVA_BANK = [
  { q:"Define major and minor losses in pipe flow.",
    model:"Major losses are due to friction along straight pipe length (Darcy-Weisbach). Minor losses arise from fittings, bends, valves, entries and exits. In long pipes major losses dominate." },
  { q:"State the Darcy-Weisbach equation and define each term.",
    model:"hf = f·(L/D)·(V²/2g). hf = head loss (m), f = Darcy friction factor (dimensionless), L = pipe length (m), D = internal diameter (m), V = mean velocity (m/s), g = 9.81 m/s²." },
  { q:"How is discharge measured using the collecting tank method?",
    model:"A known volume of water is collected in a tank while the time elapsed is recorded with a stopwatch. Q = Volume / Time. Multiple readings are averaged to reduce error." },
  { q:"Why is mercury used in the differential manometer?",
    model:"Mercury has a very high density (~13,600 kg/m³) compared to water (~1,000 kg/m³). The large density difference produces a measurable manometer deflection even for small pressure differences, improving accuracy." },
  { q:"How does pipe diameter affect friction factor at the same flow rate?",
    model:"Smaller diameter increases velocity, hence Re, and also increases relative roughness ε/D. Both effects tend to increase f. From our data, D=21.5 mm gives lower f than D=27 mm at similar Re, because absolute roughness ε is the same but ε/D is slightly larger — this is reversed because the 21.5 mm pipe may be smoother in this experiment." },
  { q:"What is the significance of the Reynolds number in this experiment?",
    model:"Re = ρVD/μ. It indicates the flow regime. All values here exceed 30,000, confirming fully turbulent flow. In turbulent flow the friction factor depends on both Re and relative roughness ε/D (Moody chart), unlike laminar flow where f = 64/Re." },
  { q:"What are the main sources of experimental error in this setup?",
    model:"(1) Parallax error in reading manometer. (2) Human reaction time in stopwatch operation. (3) Pulsating flow affecting manometer stability. (4) Air bubbles in manometer tubes. (5) Temperature variation changing viscosity." },
];
