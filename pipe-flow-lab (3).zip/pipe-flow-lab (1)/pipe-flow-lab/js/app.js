/* ── app.js — Main Application Logic ────────────────────────────────────── */

document.addEventListener('DOMContentLoaded', () => {
  Anim.init();
  initNav();
  initExperiment();
  initFormulas();
  initCalc();
  initQuiz();
  initViva();
  initGraph();
  initReport();
});

// ── Navigation ────────────────────────────────────────────────────────────────
function initNav() {
  const tabs = document.querySelectorAll('.nav-tab');
  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      tabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      document.querySelectorAll('.tab-section').forEach(s => s.classList.remove('active'));
      document.getElementById('sec-' + tab.dataset.tab).classList.add('active');
    });
  });
}

// ── Experiment Tab ────────────────────────────────────────────────────────────
let currentRow = null;

function initExperiment() {
  // Diameter buttons
  document.querySelectorAll('[data-diam]').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('[data-diam]').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
    });
  });

  // Flow buttons
  document.querySelectorAll('[data-flow]').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('[data-flow]').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
    });
  });

  // Run
  document.getElementById('btnRun').addEventListener('click', runExperiment);
}

function runExperiment() {
  const dBtn = document.querySelector('[data-diam].active');
  const fBtn = document.querySelector('[data-flow].active');
  if (!dBtn || !fBtn) { alert('Please select both a pipe diameter and flow level.'); return; }

  const D     = parseFloat(dBtn.dataset.diam);
  const flow  = parseInt(fBtn.dataset.flow);
  currentRow  = getRow(D, flow);

  if (!currentRow) return;

  // Animate
  Anim.setCondition(currentRow);

  // Update readings
  updateReadings(currentRow);

  // Update status
  document.querySelector('.status-dot').classList.add('running');
  document.querySelector('.status-dot').classList.remove('idle');
  document.getElementById('statusLabel').textContent = `Running — D=${D*1000} mm, Flow Level ${flow}`;

  // Show dynamic results
  showActiveResults(currentRow);
}

function updateReadings(row) {
  const fields = {
    'rTime': row.time.toFixed(2) + '  s',
    'rHHg':  row.hHg + '  mm',
    'rD':    (row.D * 1000) + '  mm',
  };
  Object.entries(fields).forEach(([id, val]) => {
    const el = document.getElementById(id);
    if (el) el.textContent = val;
  });
}

function showActiveResults(row) {
  const wrap = document.getElementById('activeResultsWrap');
  if (!row) return;

  const html = `
    <div style="background: var(--panel); border: 1px solid var(--border); border-radius: 8px; padding: 20px;">
      <h3 style="color: var(--accent); margin-bottom: 16px;">Results for D = ${row.D * 1000} mm, Flow Level ${row.flow}</h3>
      
      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
        <div>
          <h4 style="margin-bottom: 10px; color: var(--muted);">Measurements</h4>
          <table style="width: 100%; border-collapse: collapse; font-size: 13px;">
            <tr><td style="padding: 6px; border-bottom: 1px solid var(--border);">Time to collect 20cm (24L)</td><td style="padding: 6px; border-bottom: 1px solid var(--border); text-align: right;" class="text-mono">${row.time} s</td></tr>
            <tr><td style="padding: 6px; border-bottom: 1px solid var(--border);">Manometer Diff (hHg)</td><td style="padding: 6px; border-bottom: 1px solid var(--border); text-align: right;" class="text-mono">${row.hHg} mm</td></tr>
          </table>
        </div>
        <div>
          <h4 style="margin-bottom: 10px; color: var(--muted);">Calculations</h4>
          <table style="width: 100%; border-collapse: collapse; font-size: 13px;">
            <tr><td style="padding: 6px; border-bottom: 1px solid var(--border);">Discharge (Q)</td><td style="padding: 6px; border-bottom: 1px solid var(--border); text-align: right;" class="text-mono">${(row.Q * 1e6).toFixed(3)} ×10⁻⁶ m³/s</td></tr>
            <tr><td style="padding: 6px; border-bottom: 1px solid var(--border);">Velocity (V)</td><td style="padding: 6px; border-bottom: 1px solid var(--border); text-align: right;" class="text-mono">${row.V.toFixed(3)} m/s</td></tr>
            <tr><td style="padding: 6px; border-bottom: 1px solid var(--border);">Head Loss (hf)</td><td style="padding: 6px; border-bottom: 1px solid var(--border); text-align: right;" class="text-mono">${row.hf.toFixed(3)} m</td></tr>
            <tr><td style="padding: 6px; border-bottom: 1px solid var(--border);">Reynolds No. (Re)</td><td style="padding: 6px; border-bottom: 1px solid var(--border); text-align: right;" class="text-mono">${Math.round(row.Re).toLocaleString()}</td></tr>
            <tr><td style="padding: 6px; border-bottom: 1px solid var(--border); color: var(--accent2); font-weight: bold;">Friction Factor (f)</td><td style="padding: 6px; border-bottom: 1px solid var(--border); text-align: right; color: var(--accent2); font-weight: bold;" class="text-mono">${row.f}</td></tr>
          </table>
        </div>
      </div>
      
      <div style="margin-top: 20px; padding: 16px; background: rgba(59,130,246,0.05); border: 1px solid rgba(59,130,246,0.2); border-radius: 8px;">
        <h4 style="color: var(--accent); margin-bottom: 8px; font-size: 13px;">Darcy-Weisbach Formula Applied</h4>
        <div style="font-family: var(--font-mono); font-size: 14px; color: var(--text); display: flex; align-items: center; justify-content: center; gap: 20px; margin-top: 10px;">
           <span>hf = f · (L/D) · (V² / 2g)</span>
           <span>&rarr;</span>
           <span>f = <span style="color:var(--accent2);">(2g · D · hf) / (L · V²)</span></span>
        </div>
        <p style="text-align: center; margin-top: 12px; font-size: 13px; color: var(--muted);">f = (2 × 9.81 × ${row.D} × ${row.hf.toFixed(3)}) / (1.5 × ${row.V.toFixed(3)}²) = <strong style="color:var(--accent2)">${row.f}</strong></p>
      </div>
    </div>
  `;
  wrap.innerHTML = html;
}

// ── Formulas Tab ──────────────────────────────────────────────────────────────
function initFormulas() {
  const FORMULAS = [
    { name:'Flow Rate',        eq:'Q = V_collected / t',              desc:'Volume collected in tank divided by time taken (m³/s).' },
    { name:'Pipe Area',        eq:'A = π D² / 4',                    desc:'Cross-sectional area of the pipe (m²). D = internal diameter.' },
    { name:'Mean Velocity',    eq:'V = Q / A',                       desc:'Mean flow velocity across the cross-section (m/s).' },
    { name:'Head Loss',        eq:'hf = hHg (ρHg/ρ − 1)',           desc:'Convert manometer reading to equivalent water head. ρHg = 13600 kg/m³.' },
    { name:'Reynolds Number',  eq:'Re = ρVD / μ',                    desc:'Ratio of inertial to viscous forces. Re > 4000 → turbulent.' },
    { name:'Friction Factor',  eq:'f = 2g·hf·D / (4·L·V²)',           desc:'Friction factor from measured head loss (Darcy–Weisbach with 4f).' },
    { name:'Darcy–Weisbach',   eq:'hf = 4f·(L/D)·(V²/2g)',          desc:'The governing equation relating head loss to flow conditions.' },
    { name:'Discharge coeff.', eq:'Cd = Q_actual / Q_theoretical',   desc:'Ratio of actual to theoretical discharge (dimensionless).' },
  ];

  const grid = document.getElementById('formulaGrid');
  FORMULAS.forEach(f => {
    const el = document.createElement('div');
    el.className = 'formula-card';
    el.innerHTML = `
      <div class="f-name">${f.name}</div>
      <div class="f-eq">${f.eq}</div>
      <div class="f-desc">${f.desc}</div>
    `;
    grid.appendChild(el);
  });
}

// ── Calculations Tab ──────────────────────────────────────────────────────────
function initCalc() {
  const grid = document.getElementById('calcGrid');

  DATASET.forEach(row => {
    const card = document.createElement('div');
    card.className = 'calc-card';
    card.innerHTML = `
      <h3>Obs ${row.id} — D = ${row.D*1000} mm, Flow Level ${row.flow}</h3>

      <div class="input-row">
        <label>Q (×10⁻⁶)</label>
        <input type="number" step="0.01" id="calc_Q_${row.id}" placeholder="m³/s ×10⁻⁶">
      </div>
      <div class="feedback-msg" id="fb_Q_${row.id}"></div>

      <div class="input-row">
        <label>V (m/s)</label>
        <input type="number" step="0.001" id="calc_V_${row.id}" placeholder="m/s">
      </div>
      <div class="feedback-msg" id="fb_V_${row.id}"></div>

      <div class="input-row">
        <label>hf (m)</label>
        <input type="number" step="0.001" id="calc_hf_${row.id}" placeholder="m">
      </div>
      <div class="feedback-msg" id="fb_hf_${row.id}"></div>

      <div class="input-row">
        <label>Re</label>
        <input type="number" step="1" id="calc_Re_${row.id}" placeholder="">
      </div>
      <div class="feedback-msg" id="fb_Re_${row.id}"></div>

      <div class="input-row">
        <label>f</label>
        <input type="number" step="0.0001" id="calc_f_${row.id}" placeholder="">
      </div>
      <div class="feedback-msg" id="fb_f_${row.id}"></div>

      <button class="btn-check" onclick="checkCalc(${row.id})">Check Answers</button>
    `;
    grid.appendChild(card);
  });
}

function checkCalc(id) {
  const row = DATASET.find(r => r.id === id);
  if (!row) return;

  const checks = [
    { field: 'Q',  ref: row.Q * 1e6,  label: 'Flow rate' },
    { field: 'V',  ref: row.V,         label: 'Velocity' },
    { field: 'hf', ref: row.hf,        label: 'Head loss' },
    { field: 'Re', ref: row.Re,        label: 'Reynolds No.' },
    { field: 'f',  ref: row.f,         label: 'Friction factor' },
  ];

  checks.forEach(c => {
    const inp = document.getElementById(`calc_${c.field}_${id}`);
    const fb  = document.getElementById(`fb_${c.field}_${id}`);
    const val = parseFloat(inp.value);

    if (isNaN(val)) {
      inp.className = '';
      fb.textContent = '';
      fb.className = 'feedback-msg';
      return;
    }

    const ok = withinTol(val, c.ref, 5);
    inp.className = ok ? 'valid' : 'invalid';

    if (ok) {
      fb.textContent = `✓ Correct! (Ref: ${c.ref.toFixed(4)})`;
      fb.className = 'feedback-msg ok';
    } else {
      const err = ((val - c.ref) / c.ref * 100).toFixed(1);
      fb.textContent = `✗ Off by ${err}%. Expected ≈ ${c.ref.toFixed(4)}`;
      fb.className = 'feedback-msg err';
    }
  });
}

// ── Quiz ──────────────────────────────────────────────────────────────────────
let quizState = { idx: 0, score: 0, answered: false, results: [] };

function initQuiz() {
  document.getElementById('btnStartQuiz').addEventListener('click', startQuiz);
  document.getElementById('btnNextQ').addEventListener('click', nextQuestion);
  document.getElementById('btnRetakeQuiz').addEventListener('click', startQuiz);
  renderQuiz();
}

function startQuiz() {
  quizState = { idx: 0, score: 0, answered: false, results: [] };
  document.getElementById('quizScoreCard').style.display = 'none';
  document.getElementById('quizQCard').style.display = 'block';
  document.getElementById('btnStartQuiz').style.display = 'none';
  renderQuestion();
  renderProgress();
}

function renderQuestion() {
  const q = QUIZ_BANK[quizState.idx];
  document.getElementById('quizQNum').textContent = `Question ${quizState.idx + 1} of ${QUIZ_BANK.length}`;
  document.getElementById('quizQText').textContent = q.q;

  const optWrap = document.getElementById('quizOptions');
  optWrap.innerHTML = '';
  q.opts.forEach((opt, i) => {
    const btn = document.createElement('button');
    btn.className = 'quiz-opt';
    btn.textContent = opt;
    btn.onclick = () => answerQuiz(i);
    optWrap.appendChild(btn);
  });

  document.getElementById('quizFeedback').style.display = 'none';
  document.getElementById('btnNextQ').style.display = 'none';
  quizState.answered = false;
}

function answerQuiz(chosen) {
  if (quizState.answered) return;
  quizState.answered = true;

  const q    = QUIZ_BANK[quizState.idx];
  const opts = document.querySelectorAll('.quiz-opt');
  const fb   = document.getElementById('quizFeedback');
  const correct = chosen === q.ans;

  opts.forEach((btn, i) => {
    btn.disabled = true;
    if (i === q.ans) btn.classList.add('correct');
    if (i === chosen && !correct) btn.classList.add('wrong');
  });

  if (correct) {
    quizState.score++;
    fb.className = 'quiz-feedback correct';
    fb.textContent = '✓ Correct!';
  } else {
    fb.className = 'quiz-feedback wrong';
    fb.textContent = `✗ Incorrect. The answer is: "${q.opts[q.ans]}"`;
  }
  fb.style.display = 'block';
  quizState.results.push(correct ? 'done' : 'wrong');
  renderProgress();

  document.getElementById('btnNextQ').style.display = 'inline-block';
}

function nextQuestion() {
  quizState.idx++;
  if (quizState.idx >= QUIZ_BANK.length) {
    showQuizScore();
  } else {
    renderQuestion();
    renderProgress();
  }
}

function showQuizScore() {
  document.getElementById('quizQCard').style.display = 'none';
  const sc  = document.getElementById('quizScoreCard');
  const pct = Math.round(quizState.score / QUIZ_BANK.length * 100);
  document.getElementById('quizScoreBig').textContent = `${quizState.score}/${QUIZ_BANK.length}`;
  document.getElementById('quizScoreMsg').textContent = pct >= 80
    ? '🎉 Excellent work! You have a strong understanding of pipe flow principles.'
    : pct >= 60
      ? '👍 Good effort. Review the formulas and try again to improve further.'
      : '📖 Keep studying! Revisit the theory and experiment sections, then retake.';
  sc.style.display = 'block';
  document.getElementById('btnRetakeQuiz').style.display = 'inline-block';
}

function renderProgress() {
  const wrap = document.getElementById('quizProgress');
  wrap.innerHTML = '';
  QUIZ_BANK.forEach((_, i) => {
    const dot = document.createElement('div');
    dot.className = 'quiz-dot';
    if (i < quizState.idx)          dot.classList.add(quizState.results[i] === 'done' ? 'done' : 'wrong');
    else if (i === quizState.idx)   dot.classList.add('current');
    wrap.appendChild(dot);
  });
}

function renderQuiz() {
  document.getElementById('quizQCard').style.display = 'none';
  document.getElementById('quizScoreCard').style.display = 'none';
  document.getElementById('btnRetakeQuiz').style.display = 'none';
}

// ── Viva ──────────────────────────────────────────────────────────────────────
function initViva() {
  const wrap = document.getElementById('vivaWrap');
  VIVA_BANK.forEach((item, i) => {
    const card = document.createElement('div');
    card.className = 'viva-q-card';
    card.innerHTML = `
      <div class="viva-q-header" onclick="toggleViva(this)">
        <span class="q-text"><strong>Q${i+1}.</strong> ${item.q}</span>
        <span class="chevron">▼</span>
      </div>
      <div class="viva-answer">
        <div class="viva-model-label">Model Answer</div>
        <p class="viva-answer-text">${item.model}</p>
        <div style="margin-top:10px;">
          <div class="viva-model-label" style="color:#64748b">Your Answer (Practice)</div>
          <textarea class="student-viva-input" placeholder="Write your answer here for self-assessment..."></textarea>
        </div>
      </div>
    `;
    wrap.appendChild(card);
  });
}

function toggleViva(header) {
  const card = header.parentElement;
  card.classList.toggle('open');
}

// ── Graph Tab ─────────────────────────────────────────────────────────────────
function initGraph() {
  const ctx27 = document.getElementById('chartD27').getContext('2d');
  const ctx21 = document.getElementById('chartD21').getContext('2d');

  const data27 = DATASET.filter(r => r.D === 0.027).map(r => ({x: r.Re, y: r.f})).sort((a,b)=>a.x-b.x);
  const data21 = DATASET.filter(r => r.D === 0.0215).map(r => ({x: r.Re, y: r.f})).sort((a,b)=>a.x-b.x);

  const commonOptions = {
    responsive: true,
    scales: {
      x: { 
        title: { display: true, text: 'Reynolds Number (Re)' },
        type: 'linear',
        position: 'bottom'
      },
      y: { 
        title: { display: true, text: 'Coefficient of Friction (f)' },
        beginAtZero: false
      }
    }
  };

  new Chart(ctx27, {
    type: 'line',
    data: {
      datasets: [{
        label: 'f vs Re (27 mm Pipe)',
        data: data27,
        borderColor: '#3b82f6',
        backgroundColor: '#3b82f6',
        showLine: true,
        pointRadius: 5,
        tension: 0.1
      }]
    },
    options: {
      ...commonOptions,
      plugins: {
        title: { display: true, text: 'Diameter = 27 mm' },
        legend: { display: false }
      }
    }
  });

  new Chart(ctx21, {
    type: 'line',
    data: {
      datasets: [{
        label: 'f vs Re (21.5 mm Pipe)',
        data: data21,
        borderColor: '#f59e0b',
        backgroundColor: '#f59e0b',
        showLine: true,
        pointRadius: 5,
        tension: 0.1
      }]
    },
    options: {
      ...commonOptions,
      plugins: {
        title: { display: true, text: 'Diameter = 21.5 mm' },
        legend: { display: false }
      }
    }
  });
}

// ── Report Tab ────────────────────────────────────────────────────────────────
function initReport() {
  document.getElementById('btnGenReport').addEventListener('click', generatePDF);
}

function generatePDF() {
  const name   = document.getElementById('stuName').value    || 'Student';
  const roll   = document.getElementById('stuRoll').value    || 'N/A';
  const date   = document.getElementById('stuDate').value    || new Date().toLocaleDateString();
  const batch  = document.getElementById('stuBatch').value   || 'N/A';

  const rows = DATASET.map(r => `
    <tr>
      <td>${r.id}</td>
      <td>${r.D*1000}</td>
      <td>${r.flow}</td>
      <td>${r.time}</td>
      <td>${r.hHg}</td>
      <td>${(r.Q*1e6).toFixed(3)}</td>
      <td>${r.V.toFixed(3)}</td>
      <td>${r.hf.toFixed(3)}</td>
      <td>${Math.round(r.Re)}</td>
      <td>${r.f}</td>
    </tr>`).join('');

  const html = `<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Pipe Flow Lab Report</title>
<style>
  body { font-family: Arial, sans-serif; font-size: 12px; color: #1a1a1a; max-width: 900px; margin: 0 auto; padding: 24px; }
  h1 { text-align:center; font-size:18px; margin-bottom:2px; }
  h2 { font-size:13px; color:#1d4ed8; border-bottom:2px solid #1d4ed8; padding-bottom:4px; margin-top:20px; }
  .sub { text-align:center; color:#666; font-size:12px; }
  table { width:100%; border-collapse:collapse; margin-top:10px; }
  th { background:#1d4ed8; color:#fff; padding:7px 9px; font-size:11px; text-align:center; }
  td { padding:6px 9px; border:1px solid #ddd; text-align:center; font-size:11px; }
  tr:nth-child(even) td { background:#f8faff; }
  .info-grid { display:grid; grid-template-columns:1fr 1fr; gap:8px; margin-bottom:16px; }
  .info-row { display:flex; gap:8px; }
  .info-label { font-weight:bold; min-width:80px; }
  .formula-box { background:#f0f4ff; border:1px solid #c7d2fe; border-radius:6px; padding:12px; margin:8px 0; }
  .formula-item { margin-bottom:6px; }
  .formula-item span { font-family:monospace; color:#1d4ed8; font-size:13px; }
  @media print { body { margin:0; padding:12px; } }
</style>
</head>
<body>
<h1>MAJOR LOSSES IN PIPE FLOW — LABORATORY REPORT</h1>
<p class="sub">Department of Civil/Mechanical Engineering | Fluid Mechanics Laboratory</p>
<hr>

<h2>1. Student Information</h2>
<div class="info-grid">
  <div class="info-row"><span class="info-label">Name:</span> ${name}</div>
  <div class="info-row"><span class="info-label">Roll No.:</span> ${roll}</div>
  <div class="info-row"><span class="info-label">Batch:</span> ${batch}</div>
  <div class="info-row"><span class="info-label">Date:</span> ${date}</div>
</div>

<h2>2. Aim</h2>
<p>To determine the major (friction) head losses in pipes of two different diameters (27 mm and 21.5 mm) at three flow levels and to calculate the Darcy friction factor.</p>

<h2>3. Apparatus</h2>
<p>Pipe flow apparatus with pipes of 27 mm and 21.5 mm internal diameter; U-tube differential manometer with mercury; collecting tank with measuring scale; stopwatch; supply pump and control valves.</p>

<h2>4. Theory</h2>
<p>Major losses are caused by friction between the flowing fluid and the pipe wall. The Darcy–Weisbach equation governs this loss:</p>
<div class="formula-box">
  <div class="formula-item">Head loss: <span>hf = f · (L/D) · (V²/2g)</span></div>
  <div class="formula-item">Manometer: <span>hf = hHg × (ρHg/ρ − 1)</span></div>
  <div class="formula-item">Reynolds No.: <span>Re = ρVD/μ</span></div>
  <div class="formula-item">Friction factor: <span>f = 2g·hf·D / (L·V²)</span></div>
</div>

<h2>5. Observation Table</h2>
<table>
  <thead>
    <tr>
      <th>Obs</th><th>D (mm)</th><th>Flow</th><th>Time (s)</th>
      <th>hHg (mm)</th><th>Q (×10⁻⁶ m³/s)</th><th>V (m/s)</th>
      <th>hf (m)</th><th>Re</th><th>f</th>
    </tr>
  </thead>
  <tbody>${rows}</tbody>
</table>

<h2>6. Results & Discussion</h2>
<p>All six observations show fully turbulent flow (Re &gt; 30,000). The friction factor f ranges from 0.0084 to 0.018. The 27 mm pipe consistently shows higher f values than the 21.5 mm pipe at comparable Re, suggesting higher surface roughness for the larger pipe. Head loss increases with flow rate as expected from the V² dependency in the Darcy–Weisbach equation.</p>

<h2>7. Conclusion</h2>
<p>The experiment successfully demonstrates that major head losses in pipe flow are proportional to the square of velocity and inversely proportional to pipe diameter. The Darcy friction factor was determined experimentally for both pipes and agrees with turbulent flow theory on the Moody diagram.</p>

<br><br>
<p style="text-align:right">Signature: ____________________</p>
</body></html>`;

  const blob = new Blob([html], { type: 'text/html' });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href = url;
  a.download = `pipe_flow_report_${name.replace(/\s+/g,'_')}.html`;
  a.click();
  URL.revokeObjectURL(url);
}
