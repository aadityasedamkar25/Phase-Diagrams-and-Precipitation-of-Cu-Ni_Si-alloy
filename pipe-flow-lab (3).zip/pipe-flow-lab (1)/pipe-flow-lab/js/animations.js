/* ── animations.js — Unified Canvas Apparatus ─────────────── */

const Anim = (() => {
  // ── state ─────────────────────────────────────────────────────────────────
  let raf = null;
  let flowOffset = 0;
  let tankLevel  = 0;   // 0–1 (1 = 25cm, target is 0.8 = 20cm)
  let targetLevel = 0;
  let manoLeft  = 0.5;  // 0–1  normalised mercury column height left
  let manoRight = 0.5;
  let targetLeft  = 0.5;
  let targetRight = 0.5;
  let running = false;
  let currentVelocity = 1.0;  // for particle speed
  let currentDiam = 0.027;

  // Single Canvas
  let benchC, bx;

  function init() {
    benchC = document.getElementById('benchCanvas');
    if (!benchC) return;
    bx = benchC.getContext('2d');
    loop();
  }

  function setCondition(row) {
    if (!row) { running = false; return; }
    running = true;
    currentVelocity = row.V;
    currentDiam = row.D;

    // Manometer: map hHg (mm) to column height proportion
    // hHg range ~13-51 mm.  Left column falls, right rises (p1 > p2).
    const hNorm = row.hHg / 60;   // 60 mm = full deflection
    targetLeft  = 0.3 - hNorm * 0.10;
    targetRight = 0.3 + hNorm * 0.35;

    // Tank: fill animation over ~3 seconds
    tankLevel = 0;
    targetLevel = 0.8; // 20cm out of 25cm
  }

  function stop() {
    running = false;
    tankLevel = 0;
    targetLevel = 0;
    targetLeft  = 0.5;
    targetRight = 0.5;
  }

  // ── Main loop ─────────────────────────────────────────────────────────────
  function loop() {
    update();
    draw();
    raf = requestAnimationFrame(loop);
  }

  function update() {
    let wobbleLeft = 0;
    let wobbleRight = 0;

    if (running) {
      flowOffset = (flowOffset + currentVelocity * 0.8) % 40;
      // Tank fills slowly
      tankLevel += (targetLevel - tankLevel) * 0.008;
      
      // Simulate pressure fluctuations in turbulent flow
      const timeT = Date.now() / 100;
      const turbulence = currentVelocity > 1.5 ? 0.008 : 0.003;
      wobbleLeft = Math.sin(timeT) * turbulence;
      wobbleRight = -Math.sin(timeT * 1.1) * turbulence;
    } else {
      // drain slowly
      tankLevel += (0 - tankLevel) * 0.04;
    }
    
    manoLeft  += ((targetLeft + wobbleLeft)  - manoLeft)  * 0.04;
    manoRight += ((targetRight + wobbleRight) - manoRight) * 0.04;
  }

  function draw() {
    if (!bx) return;
    const W = benchC.width;
    const H = benchC.height;
    
    bx.clearRect(0, 0, W, H);
    
    // Background Grid for lab feel
    bx.strokeStyle = '#1e293b';
    bx.lineWidth = 1;
    for(let i=0; i<W; i+=40) {
       bx.beginPath(); bx.moveTo(i,0); bx.lineTo(i,H); bx.stroke();
    }
    for(let i=0; i<H; i+=40) {
       bx.beginPath(); bx.moveTo(0,i); bx.lineTo(W,i); bx.stroke();
    }

    // Positions
    const pipeY = 140;
    const pipeR = currentDiam > 0.025 ? 24 : 18;
    const pipeX0 = 40;
    const pipeX1 = 580; // Extends to tank
    const tap1X = 200;
    const tap2X = 400;
    
    const manoY = 440; // bottom of manometer
    const manoTubeH = 200;
    
    const tankX = 600;
    const tankY = 200;
    const tankW = 120;
    const tankH = 220;

    // ── 1. DRAW MANOMETER TUBES (BEHIND PIPE) ─────────────
    bx.strokeStyle = '#475569';
    bx.lineWidth = 3;
    
    // Left tap tube
    bx.beginPath();
    bx.moveTo(tap1X, pipeY + pipeR + 5);
    bx.lineTo(tap1X, manoY - manoTubeH);
    bx.stroke();
    
    // Right tap tube
    bx.beginPath();
    bx.moveTo(tap2X, pipeY + pipeR + 5);
    bx.lineTo(tap2X, manoY - manoTubeH);
    bx.stroke();

    // U-Tube Outline
    const tubeW = 20;
    bx.strokeStyle = '#334155';
    bx.lineWidth = 2;
    bx.strokeRect(tap1X - tubeW/2, manoY - manoTubeH, tubeW, manoTubeH);
    bx.strokeRect(tap2X - tubeW/2, manoY - manoTubeH, tubeW, manoTubeH);
    
    // Bottom connector
    bx.beginPath();
    bx.moveTo(tap1X + tubeW/2, manoY);
    bx.lineTo(tap2X - tubeW/2, manoY);
    bx.stroke();
    
    // Mercury and Water inside Manometer
    const mercH_L = manoTubeH * manoLeft * 0.55;
    const mercH_R = manoTubeH * manoRight * 0.55;
    const waterH_L = manoTubeH * 0.35;
    const waterH_R = manoTubeH * 0.35;

    // Mercury
    bx.fillStyle = 'rgba(148,163,184,0.85)';
    bx.fillRect(tap1X - tubeW/2 + 1, manoY - mercH_L, tubeW - 2, mercH_L);
    bx.fillRect(tap2X - tubeW/2 + 1, manoY - mercH_R, tubeW - 2, mercH_R);
    bx.fillRect(tap1X + tubeW/2, manoY - 10, tap2X - tap1X - tubeW, 10);

    // Water above mercury
    bx.fillStyle = 'rgba(59,130,246,0.6)';
    bx.fillRect(tap1X - tubeW/2 + 1, manoY - mercH_L - waterH_L, tubeW - 2, waterH_L);
    bx.fillRect(tap2X - tubeW/2 + 1, manoY - mercH_R - waterH_R, tubeW - 2, waterH_R);
    
    // Labels for Manometer
    bx.fillStyle = '#fbbf24';
    bx.font = 'bold 12px Space Grotesk';
    bx.textAlign = 'center';
    bx.fillText('U-Tube Manometer (Mercury)', (tap1X + tap2X)/2, manoY + 28);
    
    // Difference arrow
    const yL = manoY - mercH_L;
    const yR = manoY - mercH_R;
    if (Math.abs(yL - yR) > 5) {
      const aX = (tap1X + tap2X) / 2;
      const tY = Math.min(yL, yR);
      const bY = Math.max(yL, yR);
      
      bx.beginPath(); bx.moveTo(aX, tY); bx.lineTo(aX, bY);
      bx.strokeStyle = '#fbbf24'; bx.lineWidth=1.5; bx.setLineDash([4,4]); bx.stroke(); bx.setLineDash([]);
      
      bx.fillStyle = '#fbbf24';
      bx.fillText('hHg Diff', aX + 35, (tY+bY)/2 + 4);
    }

    // ── 2. DRAW MAIN PIPE ─────────────
    const grad = bx.createLinearGradient(0, pipeY - pipeR - 8, 0, pipeY + pipeR + 8);
    grad.addColorStop(0,   '#1e3a4a');
    grad.addColorStop(0.3, '#1d6fa4');
    grad.addColorStop(0.7, '#1d6fa4');
    grad.addColorStop(1,   '#0e2233');

    // Outer pipe
    bx.beginPath();
    bx.rect(pipeX0, pipeY - pipeR - 8, pipeX1 - pipeX0, (pipeR + 8) * 2);
    bx.fillStyle = grad;
    bx.fill();
    
    // Inner water channel
    bx.beginPath();
    bx.rect(pipeX0, pipeY - pipeR, pipeX1 - pipeX0, pipeR * 2);
    bx.fillStyle = running ? 'rgba(30,80,140,0.9)' : 'rgba(20,50,100,0.5)';
    bx.fill();

    // Flow Particles
    if (running) {
      bx.save();
      bx.beginPath(); bx.rect(pipeX0, pipeY - pipeR, pipeX1 - pipeX0, pipeR * 2); bx.clip();
      
      const timeT = Date.now() / 1000;
      const numParticles = Math.floor(currentVelocity * 60); 
      for (let i = 0; i < numParticles; i++) {
        const pSeed = (i * 1234.5678) % 1;
        const pSpeed = 0.5 + pSeed;
        const pSize = 1 + (pSeed * 4);
        const yWobble = Math.sin(timeT * 5 + i) * (pipeR * 0.5);
        
        let xp = pipeX0 + (((timeT * currentVelocity * 150 * pSpeed) + i * 40) % (pipeX1 - pipeX0 + 20));
        let yp = pipeY + yWobble + ((pSeed - 0.5) * pipeR * 1.2);

        bx.beginPath(); bx.arc(xp, yp, pSize, 0, Math.PI * 2);
        bx.fillStyle = `rgba(200,230,255,${0.3 + pSeed * 0.4})`; bx.fill();
        
        bx.beginPath(); bx.ellipse(xp - 10, yp, 8 + pSize*2, pSize*0.5, 0, 0, Math.PI * 2);
        bx.fillStyle = `rgba(150,210,255,${0.2 + pSeed * 0.2})`; bx.fill();
      }
      bx.restore();
    }

    // Pipe highlights
    bx.fillStyle = 'rgba(255,255,255,0.15)';
    bx.fillRect(pipeX0, pipeY - pipeR - 8, pipeX1 - pipeX0, 3);

    // Tapping points labels
    bx.fillStyle = '#cbd5e1'; bx.font = '12px Space Grotesk';
    bx.fillText('Tap P₁', tap1X, pipeY - pipeR - 15);
    bx.fillText('Tap P₂', tap2X, pipeY - pipeR - 15);
    
    // Pipe Info
    bx.textAlign = 'left'; bx.fillStyle = '#3b82f6';
    bx.fillText(`Test Section: L = 1.5 m`, tap1X + 40, pipeY - pipeR - 15);

    // Flow direction arrow
    const arrowX = pipeX0 + 40;
    bx.beginPath(); bx.moveTo(arrowX - 15, pipeY); bx.lineTo(arrowX + 15, pipeY);
    bx.lineTo(arrowX + 5, pipeY - 8); bx.moveTo(arrowX + 15, pipeY); bx.lineTo(arrowX + 5, pipeY + 8);
    bx.strokeStyle = running ? '#38bdf8' : '#334155'; bx.lineWidth = 3; bx.stroke();

    // ── 3. DRAW DOWN-SPOUT INTO TANK ─────────────
    // Water falling from pipe end into tank
    const spoutX = pipeX1;
    const spoutY = pipeY + pipeR;
    
    if (running) {
       bx.beginPath();
       bx.moveTo(spoutX, spoutY);
       
       const waveY = tankY + tankH - (tankH * tankLevel);
       const targetSpoutY = Math.max(spoutY, waveY);
       const timeT = Date.now();
       const streamWobble = Math.sin(timeT / 50) * 3;
       
       bx.lineTo(spoutX + streamWobble, targetSpoutY);
       bx.strokeStyle = 'rgba(100,190,255,0.7)';
       bx.lineWidth = 6 + currentVelocity * 2;
       bx.stroke();
       
       // Splashes at the surface
       if (tankLevel > 0 && tankLevel < 1) {
         const numSplashes = Math.floor(currentVelocity * 5);
         for (let i = 0; i < numSplashes; i++) {
           const pSeed = ((i * 123 + timeT) % 100) / 100;
           const spX = spoutX + streamWobble + (Math.random() - 0.5) * 20;
           const spY = targetSpoutY - (pSeed * 15);
           bx.beginPath(); bx.arc(spX, spY, 1 + Math.random()*2, 0, Math.PI*2);
           bx.fillStyle = `rgba(150,210,255,${1 - pSeed})`; bx.fill();
         }
       }
    }
    
    // Spout nozzle casing
    bx.fillStyle = '#0e2233';
    bx.fillRect(spoutX - 12, pipeY - pipeR - 8, 24, pipeR*2 + 20);

    // ── 4. DRAW COLLECTING TANK ─────────────
    bx.strokeStyle = '#475569';
    bx.lineWidth = 3;
    bx.strokeRect(tankX, tankY, tankW, tankH);
    
    bx.fillStyle = '#cbd5e1'; bx.textAlign = 'center'; bx.font = 'bold 12px Space Grotesk';
    bx.fillText('Collecting Tank', tankX + tankW/2, tankY - 12);
    bx.font = '10px Space Grotesk'; bx.fillStyle = '#64748b';
    bx.fillText('Area: 0.12 m²', tankX + tankW/2, tankY + tankH + 16);

    const fillH = tankH * tankLevel;
    if (fillH > 0) {
      const waveY = tankY + tankH - fillH;
      bx.save();
      bx.beginPath(); bx.rect(tankX+1, tankY+1, tankW-2, tankH-2); bx.clip();
      
      bx.fillStyle = 'rgba(30,80,150,0.7)';
      bx.fillRect(tankX+1, waveY, tankW-2, fillH);
      
      bx.beginPath();
      const wOff = (flowOffset / 40) * Math.PI * 2;
      bx.moveTo(tankX, waveY);
      for(let x = tankX; x <= tankX + tankW; x += 5) {
         bx.lineTo(x, waveY + Math.sin((x - tankX)*0.1 + wOff)*4);
      }
      bx.lineTo(tankX + tankW, waveY + fillH); bx.lineTo(tankX, waveY + fillH);
      bx.fillStyle = 'rgba(59,130,246,0.25)'; bx.fill();
      bx.restore();
    }
    
    // Tank graduations (every 5cm up to 25cm)
    bx.strokeStyle = '#334155'; bx.lineWidth = 1; bx.fillStyle = '#94a3b8';
    bx.font = '10px JetBrains Mono'; bx.textAlign = 'left';
    for(let i=1; i<=5; i++) {
       const cm = i * 5;
       const yPos = tankY + tankH - (tankH * (cm/25));
       bx.beginPath(); bx.moveTo(tankX, yPos); bx.lineTo(tankX+15, yPos); bx.stroke();
       bx.fillText(cm + 'cm', tankX+20, yPos+4);
    }
    
    // Fill indicator
    bx.fillStyle = '#06d6a0'; bx.font = 'bold 14px Space Grotesk'; bx.textAlign = 'center';
    if(tankLevel > 0.05) {
       bx.fillText((tankLevel * 25).toFixed(1) + ' cm', tankX + tankW/2, tankY + tankH - 10);
    }
  }

  return { init, setCondition, stop };
})();
