# Major Losses in Pipe Flow — Virtual Lab

A fully self-contained browser-based virtual laboratory for the fluid mechanics experiment on major (friction) losses in pipe flow.

## Folder Structure

```
pipe-flow-lab/
├── index.html          ← Main entry point (open this)
├── css/
│   └── styles.css      ← All styling (dark theme, Space Grotesk font)
├── js/
│   ├── data.js         ← Experimental dataset, physics formulas, quiz bank, viva bank
│   ├── animations.js   ← Canvas animations (pipe, U-tube manometer, collecting tank)
│   └── app.js          ← UI logic, quiz engine, viva, report generation
└── README.md           ← This file
```

## Features

| Module | Description |
|--------|-------------|
| **Experiment** | Select pipe diameter (27 mm / 21.5 mm) and flow level (1/2/3), click Run to animate |
| **Pipe Animation** | Canvas-rendered flowing pipe with particles, tapping points, and flow arrow |
| **Manometer** | Animated U-tube Hg manometer with live mercury column deflection |
| **Collecting Tank** | Animated filling tank with wave effect and fill percentage |
| **Readings Panel** | Live display of all 8 measured/derived quantities |
| **Observations** | Full dataset table with active-row highlighting |
| **Theory & Formulas** | 8 formula cards + flow regime classification |
| **Calculations** | Student input fields for all 5 derived quantities, ±5% validation |
| **Quiz** | 10 MCQ questions, progress dots, instant feedback, score card |
| **Viva** | 7 accordion viva questions with model answers + student answer box |
| **Report** | Download HTML lab report with student details and observation table |

## How to Use

1. Open `index.html` in any modern browser (Chrome, Firefox, Edge, Safari)
2. No server required — works as a local file
3. Navigate using the top navigation tabs

## Experimental Dataset

| Obs | D (mm) | Flow | Time (s) | hHg (mm) | Q (×10⁻⁶) | V (m/s) | hf (m) | Re | f |
|-----|--------|------|----------|----------|-----------|---------|--------|------|---|
| 1 | 27 | 1 | 39.13 | 13 | 0.613 | 1.071 | 0.163 | 30122 | 0.012 |
| 2 | 27 | 2 | 33.04 | 25 | 0.726 | 1.268 | 0.315 | 35663 | 0.017 |
| 3 | 27 | 3 | 32.47 | 28 | 0.739 | 1.291 | 0.352 | 36309 | 0.018 |
| 4 | 21.5 | 1 | 40.16 | 26 | 0.598 | 1.646 | 0.327 | 36864 | 0.0084 |
| 5 | 21.5 | 2 | 33.82 | 45 | 0.710 | 1.954 | 0.567 | 43761 | 0.0104 |
| 6 | 21.5 | 3 | 32.60 | 51 | 0.736 | 2.027 | 0.642 | 45396 | 0.0109 |

## Physics Constants
- ρ_water = 1000 kg/m³
- ρ_Hg = 13600 kg/m³  
- μ = 0.001 Pa·s (water at 20°C)
- g = 9.81 m/s²
- L = 1.0 m (pipe length between tappings)
- Volume collected = 24 litres
